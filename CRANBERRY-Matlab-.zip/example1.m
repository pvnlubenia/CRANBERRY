% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
%    Example 1                                                              %
%                                                                           %
%                                                                           %
% This is a model in the supplementary materials of Arceo et al (2016):     %
%    ARL3-S Molecular network of Leishmaniasis infectious disease.          %
%                                                                           %
% RESULT: The network numbers are as follows:                               %
%            Species                   m         4                          %
%            Complexes                 n        11                          %
%            Reactant complexes        n_r       7                          %
%            Reversible reactions      r_rev     0                          %
%            Irreversible reactions    r_irrev   8                          %
%            Reactions                 r         8                          %
%            Linkage classes           l         3                          %
%            Strong linkage classes    sl       11                          %
%            Terminal linkage classes  t         4                          %
%            Rank                      s         4                          %
%            Reactant rank             q         4                          %
%            Deficiency                delta     4                          %
%            Reactant deficiency       delta_p   3                          %
%                                                                           %
% Reference: Arceo C, Jose E, Lao A, Mendoza E (2016) Reaction networks and %
%    kinetics of biochemical systems (supplementary materials). Math Biosci %
%    283:13-29. https://doi.org/10.1016/j.mbs.2016.10.004                   %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 1';
model = addReaction(model, 'A1->2A1', ...        % just a visual guide on how the reaction looks like
                           {'A1'}, {1}, [1], ... % reactant species, stoichiometry, kinetic order
                           {'A1'}, {2}, [ ], ... % product species, stoichiometry, "kinetic order" (if reversible)
                           false);               % reversible or not
model = addReaction(model, 'A1+A2+A4->A2+A4', ...
                           {'A1', 'A2', 'A4'}, {1, 1, 1}, [1, 1, 1], ...
                           {'A2', 'A4'}, {1, 1}, [ ], ...
                           false);
model = addReaction(model, 'A1+A2->A1+2A2', ...
                           {'A1', 'A2'}, {1, 1}, [1, 1], ...
                           {'A1', 'A2'}, {1, 2}, [ ], ...
                           false);
model = addReaction(model, 'A1+A2->A1', ...
                           {'A1', 'A2'}, {1, 1}, [1, 1], ...
                           {'A1'}, {1}, [ ], ...
                           false);
model = addReaction(model, 'A2+A4->A3+A2+A4', ...
                           {'A2', 'A4'}, {1, 1}, [1, 1], ...
                           {'A3', 'A2', 'A4'}, {1, 1, 1}, [ ], ...
                           false);
model = addReaction(model, 'A3->0', ...
                           {'A3'}, {1}, [1], ...
                           { }, { }, [ ], ...
                           false);
model = addReaction(model, 'A2+A3->A3+A2+A4', ...
                           {'A2', 'A3'}, {1, 1}, [1, 1], ...
                           {'A3', 'A2', 'A4'}, {1, 1, 1}, [ ], ...
                           false);
model = addReaction(model, 'A4->0', ...
                           {'A4'}, {1}, [1], ...
                           { }, { }, [ ], ...
                           false);

% Generate the network numbers
model = networkNumbers(model);