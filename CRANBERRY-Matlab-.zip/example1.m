% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                             %
%    Example 1                                                                %
%                                                                             %
%                                                                             %
% This is a model in the supplementary materials of Arceo et al (2016):       %
%    ARL3-S Molecular network of Leishmaniasis infectious disease.            %
%                                                                             %
% RESULT: The network numbers are as follows:                                 %
%            Species                   m         4                            %
%            Complexes                 n        11                            %
%            Reactant complexes        n_r       7                            %
%            Reversible reactions      r_rev     0                            %
%            Irreversible reactions    r_irrev   8                            %
%            Reactions                 r         8                            %
%            Linkage classes           l         3                            %
%            Strong linkage classes    sl       11                            %
%            Terminal linkage classes  t         4                            %
%            Rank                      s         4                            %
%            Reactant rank             q         4                            %
%            Deficiency                delta     4                            %
%            Reactant deficiency       delta_p   3                            %
%                                                                             %
% Reference: Arceo C, Jose E, Lao A, Mendoza E (2016) Reaction networks and   %
%    kinetics of biochemical systems (supplementary materials). Math Biosci   %
%    283:13-29. https://doi.org/10.1016/j.mbs.2016.10.004                     %
%                                                                             %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 1';
model.species = { }; % do not fill out; will be filled automatically by 'network_numbers'
model.reaction(1) = struct('id', 'A1->2A1', 'reactant', struct('species', {'A1'}, 'stoichiometry', {1}), 'product', struct('species', {'A1'}, 'stoichiometry', {2}), 'reversible', false);
model.reaction(2) = struct('id', 'A1+A2+A4->A2+A4', 'reactant', struct('species', {'A1', 'A2', 'A4'}, 'stoichiometry', {1, 1, 1}), 'product', struct('species', {'A2', 'A4'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(3) = struct('id', 'A1+A2->A1+2A2', 'reactant', struct('species', {'A1', 'A2'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'A1', 'A2'}, 'stoichiometry', {1, 2}), 'reversible', false);
model.reaction(4) = struct('id', 'A1+A2->A1', 'reactant', struct('species', {'A1', 'A2'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'A1'}, 'stoichiometry', {1}), 'reversible', false);
model.reaction(5) = struct('id', 'A2+A4->A3+A2+A4', 'reactant', struct('species', {'A2', 'A4'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'A3', 'A2', 'A4'}, 'stoichiometry', {1, 1, 1}), 'reversible', false);
model.reaction(6) = struct('id', 'A3->0', 'reactant', struct('species', {'A3'}, 'stoichiometry', {1}), 'product', struct('species', { }, 'stoichiometry', { }), 'reversible', false);
model.reaction(7) = struct('id', 'A2+A3->A3+A2+A4', 'reactant', struct('species', {'A2', 'A3'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'A3', 'A2', 'A4'}, 'stoichiometry', {1, 1, 1}), 'reversible', false);
model.reaction(8) = struct('id', 'A4->0', 'reactant', struct('species', {'A4'}, 'stoichiometry', {1}), 'product', struct('species', { }, 'stoichiometry', { }), 'reversible', false);

% Generate the network numbers
model = network_numbers(model);